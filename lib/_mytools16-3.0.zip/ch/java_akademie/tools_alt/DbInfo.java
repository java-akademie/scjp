package ch.java_akademie.tools_alt;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import ch.java_akademie.tools.MyTools;

public final class DbInfo
{
	private static DbInfo instance = null;

	final private static String H2_DRV = "org.h2.Driver";
	final private static String H2_URL = "jdbc:h2:tcp://localhost:9092/~/test";
	final private static String H2_USR = "sa";
	final private static String H2_PWD = "";

	final private static String MYSQL_DRV = "com.mysql.jdbc.Driver";
	final private static String MYSQL_URL = "jdbc:mysql://localhost:3306/jees";
	final private static String MYSQL_USR = "jees";
	final private static String MYSQL_PWD = "jees";

	final private static String POSTGRES_DRV = "org.postgresql.Driver";
	final private static String POSTGRES_URL = "jdbc:postgresql://localhost:5432/jees";
	final private static String POSTGRES_USR = "jees";
	final private static String POSTGRES_PWD = "jees";

	private String drv, url, usr, pwd;


	public static void main(String[] args)
			throws ClassNotFoundException, SQLException
	{
		instance = getInstance("POSTGRES");

		instance.show();
	}


	private static DbInfo getInstance(final String DB)
			throws ClassNotFoundException, SQLException
	{
		if (instance == null)
		{
			if ("H2".equals(DB))
			{
				instance = new DbInfo(H2_DRV, H2_URL, H2_USR, H2_PWD);
			}
			else
				if ("POSTGRES".equals(DB))
				{
					instance = new DbInfo(POSTGRES_DRV, POSTGRES_URL,
							POSTGRES_USR, POSTGRES_PWD);
				}
				else
					if ("MYSQL".equals(DB))
					{
						instance = new DbInfo(MYSQL_DRV, MYSQL_URL,
								MYSQL_USR, MYSQL_PWD);
					}

		}

		return instance;
	}

	List<String> public_tables;
	List<String> other_tables;

	private StringBuffer metaDaten;
	private Connection connection;
	private DatabaseMetaData databaseMetaData;
	private ResultSet resultSet;
	private String[] tables;

	@SuppressWarnings("unused")
	private StringBuffer sbMetadaten;

	@SuppressWarnings("unused")
	private Statement statement;

	@SuppressWarnings("unused")
	private String table;

	@SuppressWarnings("unused")
	private String str;


	public DbInfo(String drv, String url, String usr, String pwd)
			throws ClassNotFoundException, SQLException
	{
		this.drv = drv;
		this.url = url;
		this.usr = usr;
		this.pwd = pwd;

		Class.forName(drv);
		connection = DriverManager.getConnection(url, usr, pwd);

		fuelleMetaDaten();
		fuelleTables();
	}



	private void fuelleMetaDaten()
	{
		metaDaten = new StringBuffer();
		try
		{
			databaseMetaData = connection.getMetaData();

			if (databaseMetaData == null)
			{
				metaDaten.append("keine Metadaten verfuegbar \n");
			}
			else
			{
				metaDaten.append(mmd("DatabaseProductName      ",
						databaseMetaData.getDatabaseProductName()));
				metaDaten.append(mmd("DatabaseProductVersion   ",
						databaseMetaData.getDatabaseProductVersion()));
				metaDaten.append(mmd("DatabaseDriverName       ",
						databaseMetaData.getDriverName()));
				metaDaten.append(mmd("supportsOrderByUnrelated ", ""
						+ databaseMetaData.supportsOrderByUnrelated()));
				metaDaten.append(mmd("NumericFunctions         ",
						databaseMetaData.getNumericFunctions()));
				metaDaten.append(mmd("supportsTransactions     ",
						"" + databaseMetaData.supportsTransactions()));
				metaDaten.append(mmd("supportsStoredProcedures ", ""
						+ databaseMetaData.supportsStoredProcedures()));
				metaDaten.append(mmd("Procedures are           ",
						databaseMetaData.getProcedureTerm()));
			}
		}
		catch (Exception e)
		{
			metaDaten.append("Metadaten nicht ermittelbar");
		}
	}



	private void fuelleTables()
	{

		try
		{
			resultSet = databaseMetaData.getTables(null, "%", "%",
					null);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}

		try
		{
			public_tables = new ArrayList<String>();
			other_tables = new ArrayList<String>();

			while (resultSet.next())
			{
				System.out.println();
				System.out.println(resultSet.getString(1));
				System.out.println(resultSet.getString(2));
				System.out.println(resultSet.getString(3));
				System.out.println(resultSet.getString(4));
				System.out.println(resultSet.getString(5));

				String wert1 = resultSet.getString(1);

				if (wert1 != null && wert1.equals("jees"))
				{
					// MYSQL - ALLE SIND RELEVANT
					public_tables.add(resultSet.getString(3));
				}
				else
					if ("PUBLIC"
							.equals(resultSet.getString(2)
									.toUpperCase())
							&& "TABLE".equals(resultSet.getString(4)
									.toUpperCase()))
					{
						public_tables.add(resultSet.getString(3));
					}
					else
					{
						other_tables.add(resultSet.getString(3));
					}
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}


	private String mmd(String t1, String t2)
	{
		if (t2.equals(""))
		{
			t2 = "-";
		}
		t1 = t1 + "                               ";
		return "\t" + t1.substring(0, 30) + t2 + "\n";
	}


	private void show()
	{
		showDbParams();
		showMetaData();
		showTables();
		zeigeColumns();
	}



	private void showDbParams()
	{
		MyTools.uebOut("DB Params", 2);
		System.out.println("Driver   : " + drv);
		System.out.println("URL      : " + url);
		System.out.println("UserId   : " + usr);
		System.out.println("PassWord : " + pwd);
	}



	private void showMetaData()
	{
		MyTools.uebOut("Metadaten", 2);
		System.out.println(metaDaten);
	}



	private void showTables()
	{
		MyTools.uebOut("other Tables and Views", 2);


		for (String s : other_tables)
		{
			System.out.println("\t" + s);
		}


		MyTools.uebOut("public Tables and Views", 2);


		for (String s : public_tables)
		{
			System.out.println("\t" + s);
		}
	}


	private void zeigeColumns()
	{
		MyTools.uebOut("Columns", 2);

		if (tables == null)
		{
			return;
		}

		StringBuffer s = new StringBuffer("");

		try
		{
			resultSet = databaseMetaData.getColumns(null, null, "ort",
					null);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}

		try
		{
			while (resultSet.next())
			{
				String str = resultSet.getString(4);
				s.append(str + "\n");
				System.out.println(str);
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			s.append("Tabellen nicht ermittelbar\n" + e);
		}
	}
}
