package ch.java_akademie.tools_alt;

import java.sql.Connection;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.management.ServiceNotFoundException;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public final class ServiceLocator
{
	private static final String JNDI_ENV = "java:comp/env/";
	private static String jndiDataSetName = "jdbc/jeesOracle";

	private static InitialContext ctx = null;


	static
	{
		try
		{
			ctx = new InitialContext();
			showContext();
		}
		catch (NamingException e)
		{
			System.err.println(e);
		}
	}


	public static Connection getConnection()
			throws ServiceNotFoundException
	{
		try
		{
			DataSource ds = (DataSource) ctx
					.lookup(JNDI_ENV + jndiDataSetName);
			return ds.getConnection();
		}
		catch (Exception e)
		{
			System.err.println(e);
			throw new ServiceNotFoundException(e.getMessage());
		}
	}


	public static String getJndiDataSetName()
	{
		return jndiDataSetName;
	}


	public static void setJndiDataSetName(String jndiDataSetName)
	{
		ServiceLocator.jndiDataSetName = jndiDataSetName;
	}


	private static void showContext()
	{
		try
		{
			Hashtable<?, ?> env = ctx.getEnvironment();
			Enumeration<?> keys = env.keys();
			while (keys.hasMoreElements())
			{
				final String key = keys.nextElement().toString();
				System.out.println(ServiceLocator.class.getName()
						+ "-->" + key + "=" + env.get(key));
			}
		}
		catch (Exception e)
		{
			System.err.println(e);
		}
	}


	private ServiceLocator()
	{
	}

}
