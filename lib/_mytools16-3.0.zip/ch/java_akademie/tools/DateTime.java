package ch.java_akademie.tools;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Random;

/**
 * 
 * Die finale Klasse <code>DateTime</code> beinhaltet allgemein
 * benoetigte <code>static</code> Methoden fuer die
 * Datenbankprogrammierung.
 * 
 * @author Johann Mildner, Basel
 * 
 */
public final class DateTime
{

	//
	// CURRENT DATE, TIME, TIMESTAMP
	//

	/**
	 * Liefert das momentane Date.
	 * 
	 * @return the CurrentDate
	 */
	public static java.sql.Date getCurrentDate()
	{
		Calendar cal = GregorianCalendar.getInstance();
		return new java.sql.Date(cal.getTimeInMillis());
	}


	/**
	 * Liefert die momentane Time.
	 * 
	 * @return current time (1970/01/01 + current time)
	 */
	static public java.sql.Time getCurrentTime()
	{
		Calendar cal = GregorianCalendar.getInstance();
		java.sql.Timestamp ts = new java.sql.Timestamp(
				cal.getTimeInMillis());
		return new java.sql.Time(ts.getTime());
	}


	/**
	 * Liefert den momentanen Timestamp.
	 * 
	 * @return theCurrentTimestamp
	 */
	public static java.sql.Timestamp getCurrentTimestamp()
	{
		Calendar cal = GregorianCalendar.getInstance();
		java.sql.Timestamp ts = new java.sql.Timestamp(
				cal.getTimeInMillis());
		return ts;
	}



	//
	// ALTER UND GEBURTSJAHR
	//


	/**
	 * Liefert ein zufaelliges Alter. Die Haeufigkeit richtet sich nach
	 * der Gauss'schen Normalverteilung (Glockenkurve).
	 * 
	 * @param spitze
	 *            Spitze der Gauss'schen Glocke
	 * 
	 * @return aRandomAge
	 */
	static public int getRandomAge(int spitze)
	{
		Random r = new Random();
		int mult = spitze / 5;
		double age = (r.nextGaussian() * mult);
		int ageRounded = (int) (spitze + Math.round((float) age));

		int min = (int) (spitze * 0.25);
		int max = (int) (spitze * 1.75);

		if (ageRounded < min)
		{
			return min;
		}
		if (ageRounded > max)
		{
			return max;
		}

		return ageRounded;
	}


	/**
	 * Liefert das Geburtsjahr zu einem momentanen Alter.
	 * 
	 * @param age
	 *            Alter aus dem das Geburtsjahr ermittelt werden soll
	 * 
	 * @return geburtsjahr
	 */
	static public int getGeburtsjahr(int age)
	{
		int year = Calendar.getInstance().get(Calendar.YEAR);

		return year - age;
	}



	//
	// MAKE DATE
	//


	/**
	 * Liefert das Date aus year, month, day, hr, min, sec.
	 * 
	 * @param year
	 *            the Year
	 * @param month
	 *            the Month
	 * @param day
	 *            the Day
	 * @param hr
	 *            the Hour
	 * @param min
	 *            the Minute
	 * @param sec
	 *            the Second
	 * 
	 * @return aDate the Date
	 * 
	 * @throws Exception
	 *             illegal Date/Time
	 */
	static public java.sql.Date makeDate(int year, int month, int day,
			int hr, int min, int sec) throws Exception
	{
		checkDate(year, month, day, hr, min, sec, 0);

		return new java.sql.Date(
				makeGregorianCalendar(year, month, day, hr, min, sec)
						.getTimeInMillis());
	}


	/**
	 * Liefert das Date aus year, month, day.
	 * 
	 * @param year
	 *            the year
	 * @param month
	 *            the month
	 * @param day
	 *            the day
	 * 
	 * @return aDate the Date
	 * 
	 * @throws Exception
	 *             illegal Date/Time
	 */
	static public java.sql.Date makeDate(int year, int month, int day)
			throws Exception
	{
		return makeDate(year, month, day, 0, 0, 0);
	}



	/**
	 * Liefert ein zufaelliges Date im Bereich fromYear - toYear.
	 * 
	 * @param fromYear
	 *            the year from
	 * @param toYear
	 *            the year to
	 * 
	 * @return Date the Date between from and to
	 * 
	 * @throws Exception
	 *             illegal Date/Time
	 */
	static public java.sql.Date makeRandomDate(int fromYear, int toYear)
			throws Exception
	{
		int year = getRandom(fromYear, toYear);
		int month = getRandom(1, 12);
		int day = getRandom(1, lastDayOfMonth(year, month));
		return makeDate(year, month, day);
	}


	/**
	 * Liefert ein zufaelliges Date im Bereich 1950 - 2010.
	 * 
	 * @return Date in the range from 1950 to 2010
	 * 
	 * @throws Exception
	 *             illegal Date/Time
	 */
	static public java.sql.Date makeRandomDate() throws Exception
	{
		return makeRandomDate(1950, 2010);
	}



	/**
	 * Liefert ein zufaelliges Date im im Jahr year.
	 * 
	 * @param year
	 *            the year
	 * 
	 * @return a random date in that year
	 * 
	 * @throws Exception
	 *             illegal Date/Time
	 */
	static public java.sql.Date makeRandomDate(int year)
			throws Exception
	{
		return makeRandomDate(year, year);
	}



	//
	// MAKE TIME
	//



	/**
	 * Liefert die Time aus hr, min, sec.
	 * 
	 * @param hr
	 *            the hour
	 * @param min
	 *            the minute
	 * @param sec
	 *            the second
	 * 
	 * @return aTime (1970/01/01 hr:min:sec)
	 * 
	 * @throws Exception
	 *             illegal Date/Time
	 */
	static public java.sql.Time makeTime(int hr, int min, int sec)
			throws Exception
	{
		checkDate(1970, 1, 1, hr, min, sec, 0);

		return new java.sql.Time(
				makeGregorianCalendar(1970, 1, 1, hr, min, sec)
						.getTimeInMillis());
	}


	/**
	 * Liefert eine zufaellige Time.
	 * 
	 * @return a random time
	 * 
	 * @throws Exception
	 *             illegal Date/Time
	 */
	static public java.sql.Time makeRandomTime() throws Exception
	{
		return new java.sql.Time(makeGregorianCalendar(1970, 1, 1,
				getRandom(0, 23), getRandom(0, 58), getRandom(0, 59))
						.getTimeInMillis());
	}



	//
	// MAKE TIMESTAMP
	//




	/**
	 * Liefert den Timestamp aus year, month, day, hr, min, sec.
	 * 
	 * @param year
	 *            the year
	 * @param month
	 *            the month
	 * @param day
	 *            the day
	 * @param hr
	 *            the hour
	 * @param min
	 *            the minute
	 * @param sec
	 *            the second
	 * 
	 * @return aTimestamp
	 * 
	 * @throws Exception
	 *             illegal Date/Time
	 */
	static public java.sql.Timestamp makeTimestamp(int year, int month,
			int day, int hr, int min, int sec) throws Exception
	{
		return makeTimestamp(year, month, day, hr, min, sec, 0);
	}


	/**
	 * Liefert den Timestamp aus year, month, day.
	 * 
	 * @param year
	 *            the year
	 * @param month
	 *            the month
	 * @param day
	 *            the day
	 * 
	 * @return aTimestamp
	 * 
	 * @throws Exception
	 *             illegal Date/Time
	 */
	static public java.sql.Timestamp makeTimestamp(int year, int month,
			int day) throws Exception
	{
		return makeTimestamp(year, month, day, 0, 0, 0, 0);
	}


	/**
	 * Liefert den Timestamp aus year, month, day, hr, min, sec, microSec.
	 * 
	 * @param year
	 *            the year
	 * @param month
	 *            the month
	 * @param day
	 *            the day
	 * @param hr
	 *            the hour
	 * @param min
	 *            the minute
	 * @param sec
	 *            the second
	 * @param microSecond
	 *            the microSecond
	 * 
	 * @return aTimestamp
	 * 
	 * @throws Exception
	 *             illegal Date/Time
	 */
	static public java.sql.Timestamp makeTimestamp(int year, int month,
			int day, int hr, int min, int sec, int microSecond)
			throws Exception
	{
		checkDate(year, month, day, hr, min, sec, microSecond);

		java.sql.Timestamp ts = new java.sql.Timestamp(
				makeGregorianCalendar(year, month, day, hr, min, sec)
						.getTimeInMillis());
		ts.setNanos(microSecond * 1000);

		return ts;
	}


	/**
	 * Liefert einen zufaelligen Timestamp im Bereich fromYear - toYear.
	 * 
	 * @param fromYear
	 *            from year
	 * @param toYear
	 *            to year
	 * 
	 * @return aTimestamp
	 * 
	 * @throws Exception
	 *             illegal Date/Time
	 */
	static public java.sql.Timestamp makeRandomTimestamp(int fromYear,
			int toYear) throws Exception
	{
		int year = getRandom(fromYear, toYear);
		int month = getRandom(1, 12);
		int day = getRandom(1, lastDayOfMonth(year, month));
		int hour = getRandom(1, 23);
		int min = getRandom(1, 59);
		int sec = getRandom(1, 59);

		return makeTimestamp(year, month, day, hour, min, sec);
	}


	/**
	 * Liefert einen zufaelligen Timestamp im Jahr year.
	 * 
	 * @param year
	 *            the year
	 * 
	 * @return aTimestamp in that year
	 * 
	 * @throws Exception
	 *             illegal Date/Time
	 */
	static public java.sql.Timestamp makeRandomTimestamp(int year)
			throws Exception
	{
		return makeRandomTimestamp(year, year);
	}



	//
	// PRIVATER KONSTRUKTOR
	//


	/**
	 * privater Konstruktor da <code>DateTime</code> nicht instantiiert
	 * werden darf.
	 */
	private DateTime()
	{
	}



	//
	// PRIVATE METHODEN
	//


	static private Calendar makeGregorianCalendar(int year, int month,
			int day, int hr, int min, int sec) throws Exception
	{
		checkDate(year, month, day, hr, min, sec, 0);

		return new GregorianCalendar(year, month - 1, day, hr, min,
				sec);
	}



	static private boolean checkDate(int year, int month, int day,
			int hr, int min, int sec, int msec) throws Exception
	{
		boolean ok = true;

		if (hr < 0 || hr > 23 || min < 0 || min > 59 || sec < 0
				|| sec > 59 || msec < 0 || msec > 999999)
		{
			ok = false;
		}
		else
		{
			if (year < 1 || year > 9999 || month < 1 || month > 12)
			{
				ok = false;
			}
			else
			{
				if (day < 1 || day > lastDayOfMonth(year, month))
				{
					ok = false;
				}
			}
		}

		if (ok)
		{
			return ok;
		}
		else
		{
			throw new Exception("illegal Date/Time (" + year + "-"
					+ month + "-" + day + " " + hr + ":" + min + ":"
					+ sec + "." + msec + ")");
			// return false;
		}
	}



	static private int lastDayOfMonth(int year, int month)
	{
		switch (month)
		{
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				return 31;
			case 4:
			case 6:
			case 9:
			case 11:
				return 30;
			default:
				if (year % 400 == 0)
				{
					return 29;
				}

				if (year % 100 == 0)
				{
					return 28;
				}

				if (year % 4 == 0)
				{
					return 29;
				}

				return 28;
		}
	}


	static private int getRandom(int min, int max)
	{
		return (int) (Math.random() * (max - min + 1)) + min;
	}

}
