package ch.java_akademie.tools;

import java.util.Date;

/**
 * 
 * Die finale Klasse <code>TestDaten</code> dient dem Erstellen von
 * Testdaten fuer Datenbanktabellen. 
 * 
 * @author Johann Mildner, Basel
 * 
 */
public final class TestDaten
{

	private static String[] vnameWeiblich = { "brigita", "frieda", "linda",
			"karin", "heidi", "maria", "ute", "martina", "margarete",
			"ludowika", "marianne", "susanne", "gerlinde", "gabriele",
			"eva", "ullrike" };

	private static String[] vnameMaennlich = { "fritz", "urs", "oli", "hans-peter",
			"heinz", "peter", "max", "oliver", "josef", "johann", "friedrich",
			"georg", "gerhard", "robert", "johannes", "bruno" };

	private static String[] vname;


	static
	{
		vname = new String[vnameWeiblich.length + vnameMaennlich.length];

		int vnameIndex = 0;

		for (String n : vnameWeiblich)
		{
			vname[vnameIndex++] = n;
		}
		for (String n : vnameMaennlich)
		{
			vname[vnameIndex++] = n;
		}
	}

	private static String[] nname = { "mueller", "schuster", "meier",
			"allmen", "von arx", "friedrichs", "mauler", "gruber",
			"bamberger", "holterer", "german", "lugner", "strache",
			"havlik", "nigl", "meier", "maier", "strobl", "huber",
			"einstein", "vogel", "fink", "sperling" };

	private static String[] ort = { "basel", "genf", "zuerich", "wien",
			"berlin", "paris", "brugg", "bruck", "wiel", "graz",
			"klagenfurt", "krems", "muenchen", "koeln", "berlin" };

	private static String[] strasse = { "hauptstrasse", "hauptplatz",
			"gablenzgasse", "lehenmattstrasse", "gueterstrasse",
			"gerlgasse", "rheingasse", "wurmstrasse", "blumenrain",
			"zuercherstrasse", "krautacker", "im gehoeft" };


	/**
	 * privater Konstruktor da <code>TestDaten</code> nicht instantiiert
	 * werden darf.
	 */
	private TestDaten()
	{
	}


	/**
	 * @return name (vorname + " " + nachname)
	 */
	public static String getName()
	{
		return getVorname() + " " + getNachname();
	}


	/**
	 * @return adresse
	 */
	public static String getAdresse()
	{
		return getPlz() + " " + getOrt() + " " + getStrasse() + " "
				+ " " + getHausnummer();
	}



	public static String getVorname(int... geschlecht)
	{
		//
		// geschlecht:
		// 1: weiblich
		// 2: maennlich
		// sonst: egal
		//

		if (geschlecht.length == 0)
			return vname[(int) (Math.random() * vname.length)];

		if (geschlecht[0] > 2)
			return vname[(int) (Math.random() * vname.length)];

		if (geschlecht[0] == 1)
			return vnameWeiblich[(int) (Math.random() * vnameWeiblich.length)];
		else
			return vnameMaennlich[(int) (Math.random() * vnameMaennlich.length)];
	}


	/**
	 * @return nachname
	 */
	public static String getNachname()
	{
		return nname[(int) (Math.random() * nname.length)];
	}


	/**
	 * @return plz (1000-8000)
	 */
	public static int getPlz()
	{
		return (int) (1000 + Math.random() * 8000);
	}


	/**
	 * @return ort
	 */
	public static String getOrt()
	{
		return ort[(int) (Math.random() * ort.length)];
	}


	/**
	 * @return strasse
	 */
	public static String getStrasse()
	{
		return strasse[(int) (Math.random() * strasse.length)];
	}


	/**
	 * @return hausnummer(1-256)
	 */
	public static int getHausnummer()
	{
		return (int) (1 + Math.random() * 256);
	}



	public static Date getGeburtsdatum(int spitze) throws Exception
	{
		int alter = DateTime.getRandomAge(spitze);
		int jahr = DateTime.getGeburtsjahr(alter);
		return DateTime.makeRandomDate(jahr);
	}
}
