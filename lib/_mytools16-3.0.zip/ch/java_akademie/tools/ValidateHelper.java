package ch.java_akademie.tools;

/**
 * @author johann
 * 
 */
public final class ValidateHelper
{
	private ValidateHelper()
	{
	}



	/**
	 * @param string
	 *            der zu pruefende String
	 * 
	 * @return einBoolean
	 */
	public static boolean isEmpty(String string)
	{
		if (string == null)
			return true;

		if (string.trim().equals(""))
			return true;

		return false;
	}


	/**
	 * @param string
	 *            der zu pruefende String
	 *            
	 * @return einBoolean
	 */
	public static boolean isInteger(String string)
	{
		return isNumeric(string, "int");
	}


	/**
	 * @param string
	 *            der zu pruefende String
	 *            
	 * @return einBoolean
	 */
	public static boolean isDouble(String string)
	{
		return isNumeric(string, "double");
	}


	/**
	 * @param string
	 *            der zu pruefende String
	 *            
	 * @return einBoolean
	 */
	public static boolean isLong(String string)
	{
		return isNumeric(string, "long");
	}


	/**
	 * @param string
	 *            der zu pruefende String
	 *            
	 * @return einBoolean
	 */
	public static boolean isFloat(String string)
	{
		return isNumeric(string, "float");
	}


	/**
	 * @param string
	 *            der zu pruefende String
	 *            
	 * @param type
	 *            der Datentyp (int, double, long, float)
	 *            
	 * @return einBoolean
	 */
	public static boolean isNumeric(String string, String type)
	{
		if (isEmpty(string))
			return false;

		try
		{
			if (type.equals("int"))
				Integer.parseInt(string);
			else
				if (type.equals("long"))
					Long.parseLong(string);
				else
					if (type.equals("double"))
					{
						double d = Double.parseDouble(string);
						if (Double.isInfinite(d))
							return false;
					}
					else
						if (type.equals("float"))
						{
							float f = Float.parseFloat(string);
							if (Float.isInfinite(f))
								return false;
						}
		}
		catch (Exception e)
		{
			return false;
		}

		return true;
	}

}
