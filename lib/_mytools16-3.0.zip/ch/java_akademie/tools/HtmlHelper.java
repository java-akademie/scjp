package ch.java_akademie.tools;

import java.io.PrintWriter;

/**
 * 
 * Die finale Klasse <code>HtmlHelper</code> beinhaltet allgemein
 * benoetigte <code>static</code> Methoden zur Erzeugung von Html Seiten
 * in Servlets.
 * 
 * @author Johann Mildner, Basel
 * 
 */
public class HtmlHelper
{
	private final static char QU = '"';
	private final static String STYLE = "http://localhost:8080/wcds/nav/x_style.css";

	private final static String NBSP = "&nbsp;";


	/**
	 * Liefert den Html Code bis Anfang Body <code>&lt;body&gt;</code>.
	 * 
	 * @param title
	 *            der Titel
	 * 
	 * @return ein String
	 */
	public final static String beginHtmlHeadBody(String title)
	{
		StringBuilder sb = new StringBuilder();

		sb.append("<!DOCTYPE html>\n\n");
		sb.append("<html>\n\n");
		sb.append("<head>\n");
		sb.append("    <title>" + title + "</title>\n");
		sb.append("    <link " + pair("href", STYLE)
				+ pair("rel", "stylesheet") + pair("type", "text/css")
				+ " />\n");
		sb.append("</head>\n\n");
		sb.append("<body>\n");

		return sb.toString();
	}


	/**
	 * Liefert den Html Code ab Ende Body <code>&lt;/body&gt;</code>.
	 * 
	 * @return ein String
	 */
	public static String endHtmlBody()
	{
		StringBuilder sb = new StringBuilder();

		sb.append("\n</body>\n\n");
		sb.append("</html>\n\n");

		return (sb.toString());
	}


	/**
	 * @param tiefe
	 *            Einrueckung
	 * 
	 * @return html-Code
	 */
	public static String datenBegin(int tiefe)
	{
		return getLeerstellen(tiefe) + "<td>";
	}


	/**
	 * @param tiefe
	 *            Einrueckung
	 * 
	 * @return html-Code
	 */
	public static String datenEnd(int tiefe)
	{
		return getLeerstellen(tiefe) + "</td>";
	}


	public final static String endForm()
	{
		return "</form>";
	}



	public static void form1(PrintWriter pw)
	{

		pw.println(startForm("action-form1", "method"));

		pw.println(input(4, "type", "name", "value"));
		pw.println(input(4, "type", "name", "value", 20));

		pw.println(endForm());

	}


	public static void form2(PrintWriter pw)
	{

		pw.println(HtmlHelper.startForm("hallo", "post"));

		pw.println("    bitte geben Sie Ihren Namen ein:");
		pw.println(HtmlHelper.input(2, "text", "name", "hugo", 20));
		pw.println(HtmlHelper.input(2, "submit", "op", "go"));

		pw.println(HtmlHelper.endForm());
	}


	/**
	 * @param tiefe
	 *            Einrueckung
	 * @param action
	 *            Aktion
	 * @param method
	 *            Methode
	 *            
	 * @return einString
	 */
	public final static String formBegin(int tiefe, String action,
			String method)
	{
		StringBuilder sb = newStringBuilder(tiefe);

		sb.append("<form ");
		sb.append(pair("action", action));
		sb.append(pair("method", method));
		sb.append(">");

		return sb.toString() + "";
	}


	/**
	 * @param tiefe
	 *            Einrueckung
	 * 
	 * @return einString
	 */
	public final static String formEnd(int tiefe)
	{

		return getLeerstellen(tiefe) + "</form>";
	}


	/**
	 * @param tiefe
	 *            Einrueckung
	 * 
	 * @return einString
	 */
	private static String getLeerstellen(int tiefe)
	{
		StringBuilder sb = new StringBuilder();
		for (int i = 1; i <= tiefe; i++)
		{
			sb.append(" ");
		}
		return sb.toString();
	}


	/**
	 * @param tiefe
	 *            Einrueckung
	 * @param type
	 *            Typ
	 * @param name
	 *            Name
	 * @param value
	 *            Wert
	 * 
	 * @return einString
	 */
	public final static String input(int tiefe, String type,
			String name, String value)
	{
		StringBuilder sb = newStringBuilder(tiefe);
		sb.append("<input ");
		sb.append(pair("type", type));
		sb.append(pair("name", name));
		sb.append(pair("value", value));
		sb.append(" />");
		return sb.toString();
	}


	/**
	 * @param tiefe
	 *            Einrueckung
	 * @param type
	 *            Typ
	 * @param name
	 *            Name
	 * @param value
	 *            Wert
	 * @param size
	 *            Size
	 * 
	 * @return einString
	 */
	public final static String input(int tiefe, String type,
			String name, String value, int size)
	{
		StringBuilder sb = newStringBuilder(tiefe);
		sb.append("<input ");
		sb.append(pair("type", type));
		sb.append(pair("name", name));
		sb.append(pair("value", value));
		sb.append(pair("size", size));
		sb.append(" />");
		return sb.toString();
	}


	/**
	 * @param tiefe
	 *            Einrueckung
	 * @param text
	 *            Text
	 *            
	 * @return einString
	 */
	public final static String makeText(int tiefe, String text)
	{

		return getLeerstellen(tiefe) + text;
	}


	public static String nbsp(int anzahl)
	{
		StringBuilder sb = new StringBuilder();

		for (int i = 1; i <= anzahl; i++)
		{
			sb.append(NBSP);
		}
		return sb.toString();
	}


	/**
	 * @param tiefe
	 *            Einrueckung
	 * 
	 * @return einStringBuilder
	 */
	private static StringBuilder newStringBuilder(int tiefe)
	{
		StringBuilder sb = new StringBuilder();

		sb.append(getLeerstellen(tiefe));

		return sb;
	}


	/**
	 * @param name
	 *            Name
	 * @param value
	 *            Wert
	 * 
	 * @return einString
	 */
	public final static String pair(String name, int value)
	{
		// name="value"
		return String.format(" %s=%c%d%c ", name, QU, value, QU);
	}



	/**
	 * @param name
	 *            Name
	 * @param value
	 *            Wert
	 * 
	 * @return einString
	 */
	public final static String pair(String name, String value)
	{
		// name="value"
		return String.format(" %s=%c%s%c ", name, QU, value, QU);
	}



	public final static String startForm(String action, String method)
	{
		return String.format("<form %s %s>", pair("action", action),
				pair("method", method));
	}


	/**
	 * @param tiefe
	 *            Einrueckung
	 * 
	 * @return einString
	 */
	public static String tableBegin(int tiefe)
	{
		return getLeerstellen(tiefe) + "<table>";
	}



	/**
	 * @param tiefe
	 *            Einrueckung
	 * 
	 * @return einString
	 */
	public static String tableEnd(int tiefe)
	{
		return getLeerstellen(tiefe) + "</table>";
	}


	public static String trimAndFilter(String string)
	{
		if (string == null)
			return "";

		string = string.trim();

		StringBuilder filtered = new StringBuilder();

		for (int i = 0; i < string.length(); i++)
		{
			char c = string.charAt(i);
			switch (c)
			{
				case '<':
					filtered.append("&lt;");
					break;
				case '>':
					filtered.append("&gt;");
					break;
				case '"':
					filtered.append("&quot;");
					break;
				case '&':
					filtered.append("&amp;");
					break;
				default:
					filtered.append(c);
			}

		}

		return filtered.toString();
	}


	public static String ueb(int level, String string)
	{
		String hx;

		switch (level)
		{
			case 1:
				hx = "h1";
				break;
			case 2:
				hx = "h2";
				break;
			case 3:
				hx = "h3";
				break;
			case 4:
				hx = "h4";
				break;
			case 5:
			default:
				hx = "h5";
				break;
		}

		return "<" + hx + ">" + string + "</" + hx + ">" + "\n";
	}



	/**
	 * @param tiefe
	 *            Einrueckung
	 * 
	 * @return einString
	 */
	public static String zeileBegin(int tiefe)
	{
		return getLeerstellen(tiefe) + "<tr>";
	}



	/**
	 * @param tiefe
	 *            Einrueckung
	 * 
	 * @return einString
	 */
	public static String zeileEnd(int tiefe)
	{
		return getLeerstellen(tiefe) + "/tr>";
	}


}
